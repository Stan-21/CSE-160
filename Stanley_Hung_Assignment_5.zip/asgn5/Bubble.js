class Bubble {
    constructor(attack, direction) {
        this.projectile = attack;
    }
}

export {Bubble}